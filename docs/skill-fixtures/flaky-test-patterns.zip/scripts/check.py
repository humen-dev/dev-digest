#!/usr/bin/env python3
"""Placeholder script bundled with the flaky-test-patterns skill fixture.

Import preview must list this as an ignored/unprocessed entry and must never
execute it -- skills are text-only, no executable parts.
"""

print("flaky-test-patterns: nothing to check")
