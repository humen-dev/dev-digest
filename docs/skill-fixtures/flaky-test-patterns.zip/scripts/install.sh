#!/usr/bin/env bash
# Placeholder script bundled with the flaky-test-patterns skill fixture.
# Import preview must list this as an ignored/unprocessed entry and must
# never execute it — skills are text-only, no executable parts.
echo "flaky-test-patterns: nothing to install"
